package com.appmindlab.nano;

import com.journeyapps.barcodescanner.CaptureActivity;

/**
 * Created by saelim on 8/26/2015.
 */
public class CaptureActivityAnyOrientation extends CaptureActivity {
}
